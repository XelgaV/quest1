double det(double **matrix, int n, int m);
void input(double **matrix, int *n, int *m);
void output(double det);

void main()
{

}

