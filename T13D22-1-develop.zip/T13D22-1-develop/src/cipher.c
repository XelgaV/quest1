#include "cipher.h"

#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int read_file(const char *path) {
    int validFile = 1;

    FILE *file = fopen(path, "r");
    if (file == NULL) {
        validFile = 0;
    } else {
        char line[1024];
        while (fgets(line, sizeof(line), file) != NULL) {
            printf("%s", line);
        }
        int64_t _file_size = 0;
        fseek(file, 0, SEEK_END);
        _file_size = ftell(file);
        if (_file_size == 0) {
            validFile = 0;
        }
        fclose(file);
        file = NULL;
    }

    return validFile;
}

void write_in_file(const char *path) {
    FILE *file = fopen(path, "a+");
    char inputStr[256];
    fgets(inputStr, sizeof(inputStr), stdin);
    inputStr[strlen(inputStr)] = '\0';
    fprintf(file, "%s", inputStr);
    rewind(file);
    fclose(file);
}

int main() {
    char path[256];
    int working = 1;
    int was_pressed_one = 0;
    while (working) {
        char input[256];
        fgets(input, sizeof(input), stdin);
        int choice = atoi(input);
        if (choice == 1) {
            fgets(path, sizeof(path), stdin);
            if (read_file(path) == 0) {
                printf("n/a\n");
            } else {
                was_pressed_one = 1;
            }
        } else if (choice == 2 && was_pressed_one == 1) {
            write_in_file(path);
            read_file(path);
            was_pressed_one = 0;
        } else if (choice == -1) {
            working = 0;
        } else {
            printf("n/a\n");
        }
    }
    return 0;
}