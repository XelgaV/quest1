#ifndef CIPHER_H
#define CIPHER_H

int read_file(const char *path);
void write_in_file(const char *path);

#endif
