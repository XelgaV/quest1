#include <stdio.h>

int main () {
   printf ("Hello, AI!");

   return 0;
}