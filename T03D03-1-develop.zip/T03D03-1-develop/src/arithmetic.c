#include <stdio.h>

int main ()
{
  int a, b, w;
scanf ("%d %d",&a, &b);
   w = getchar ();
  if (!(w== '\0'|| w== EOF || w== '\n'))
{
  printf ("n/a");
  return 0;
}
  else if (b !=0)   {
    printf ("%d %d %d %d", a + b, a - b, a * b, a/b);}
   else {
   printf ("%d %d %d n/a", a + b, a - b, a * b);}
  return 0; 
}