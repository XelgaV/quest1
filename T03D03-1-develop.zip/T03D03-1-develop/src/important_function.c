#include <stdio.h>
#include <math.h>

int main()
{
    float a;
    float result;
    int _like;
_like=scanf("%f", &a);
    if (_like == 0) {
    printf ("n/a");
    }
    result = 7e-3 * pow( a, 4) + ((22.8 * pow( a, 1.0/3) - 1000) * a + 3) / ( a * a / 2) - a * pow( 10 + a, 2.0/a) - 1.01;

    if (result >= 0) {
        printf ("%f", result);
    } else 
    {
        printf("n/a");
    }

    return 0;
}
