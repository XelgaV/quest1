#include <stdio.h>

 int main(void) {
   printf ("Введите значение")
    int name;
    scanf ("%d", &name);
    printf ("Hello, %d!/n", name);
    return 0;
}
