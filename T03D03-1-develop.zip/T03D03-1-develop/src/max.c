 
 #include <stdio.h>

int main()
{
    int f, x, max, w;
    scanf("%d %d", &f, &x);
    w = getchar ();
  if (!(w== '\0'|| w== EOF || w== '\n'))
{
  printf ("n/a");
  return 0;
}
    if (f > x) {
        max = f;
    } else {
        max = x;
    }

    printf("%d\n", max);

    return 0;
}
