#include <stdio.h>

int readarray(int *arr) {
  char enter = 0;
  for (int a = 0; a < 10; a++) {
    if (scanf("%d%c", &arr[a], &enter) != 2 || (a == 9 && enter != '\n') ||
        (a < 9 && enter != ' ')) {
      return 0;
    }
  }
  return 1;
}

void sortarray(int *arr) {
  for (int a = 0; a < 10; a++) {
    for (int b = 0; b < 10 - 1; b++) {
      if (arr[b] > arr[b + 1]) {
        int temp = arr[b];
        arr[b] = arr[b + 1];
        arr[b + 1] = temp;
      }
    }
  }
}
void prarray(int *arr) {
  for (int a = 0; a < 10; a++) {
    printf("%d ", arr[a]);
  }
  printf("n");
}

int main() {
  int arr[10];
  if (!readarray(arr)) {
    printf("n/a");
    return 1;
  }
  sortarray(arr);
  prarray(arr);
  return 0;
}