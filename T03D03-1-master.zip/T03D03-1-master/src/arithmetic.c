#include <stdio.h>

int sum(int a, int b);

int main()
{
    return 0;
}

int sum(int a, int b){
    return (2 * a * b) / (a - b);
}