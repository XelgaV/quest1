#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "decision.h"

void main() {
    double *data;
    int n;
    int validQuntity = scanf("%d", &n);
    int lastSymbol = getchar();
    if (validQuntity == 1 && lastSymbol == 10) {
        double arr[n];
        double *data = arr;
        int valid = input(data, n);
        if (make_decision(data, n) == 1 && valid == 1)
            printf("YES");
        else
            printf("NO");
    }