#define GOLDEN_RATIO 0.618

int make_decision(double *data, int n);
