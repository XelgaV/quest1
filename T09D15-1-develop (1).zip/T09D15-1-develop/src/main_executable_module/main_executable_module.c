#include <stdio.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "../data_module/data_process.h"
#include "../yet_another_decision_module/decision.h"

int main() {
    int n;
    int validQuntity = scanf("%d", &n);
    int lastSymbol = getchar();
    if (validQuntity == 1 && lastSymbol == 10) {
        double arr[n];
        double *data = arr;

        printf("LOAD DATA...\n");

        int valid = input(data, n);

        printf("RAW DATA:\n\t");
        output(data, n);

        printf("\nNORMALIZED DATA:\n\t");
        normalization(data, n);
        output(data, n);

        printf("\nSORTED NORMALIZED DATA:\n\t");
        sort(data, n);
        output(data, n);

        printf("\nFINAL DECISION:\n\t");
        if (make_decision(data, n) == 1 && valid == 1)
            printf("YES");
        else
            printf("NO");
    }
}