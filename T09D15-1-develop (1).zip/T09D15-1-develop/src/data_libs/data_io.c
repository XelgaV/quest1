#include "data_io.h"

#include <stdio.h>
int input(double *data, int n) {
    int validArr = 1;
    for (int i = 0; i < n; i++) {
        double num;
        int waitLastSymbol = 32;
        int lastSymbol;
        if (i == n - 1) waitLastSymbol = 10;
        int valid = scanf("%lf", &num);
        lastSymbol = getchar();
        if (valid == 1 && lastSymbol == waitLastSymbol) {
            data[i] = num;
        } else {
            data[i] = 0;

            validArr = 0;
        }
    }
    return validArr;
}
void output(double *data, int n) {
    for (int i = 0; i < n; i++) {
        printf("%lf ", data[i]);
    }
}
