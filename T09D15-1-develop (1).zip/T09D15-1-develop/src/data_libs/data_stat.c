#include "data_stat.h"
double max(double *data, int n) {
    double max = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    return max;
}
double min(double *data, int n) {
    double min = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    return min;
}
double mean(double *data, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum += data[i];
    }
    return sum / n;
}
double variance(double *data, int n) {
    double S = mean(data, n);
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum += (data[i] - S) * (data[i] - S);
    }
    return sum / n;
}
void sort(double *data, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (data[i] > data[j]) {
                double tmp = data[i];
                data[j] = data[i];
                data[j] = tmp;
            }
        }
    }
}