#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "data_process.h"
int main() {
    int n;
    int validQuntity = scanf("%d", &n);
    int lastSymbol = getchar();
    if (validQuntity == 1 && lastSymbol == 10) {
        double arr[n];
        double *data = arr;
        int valid = input(data, n);
        if (normalization(data, n) == 1 && valid == 1)
            output(data, n);
        else
            printf("ERROR");
    } else {
        printf("ERROR");
    }
}