#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
void squaring(int *a, int n);

int main(void) {
    int n, data[NMAX];
    if (input(data, &n) == 0) {
        squaring(data, n);
        output(data, n);
    }
    return 0;
}

int input(int *a, int *n) {
    int flag = 0;
    char term;
    if ((scanf("%d%c", n, &term) == 2 && term == '\n') && *n > 1 && *n < NMAX) {
        for (int *p = a; p - a < *n; p++) {
            if (scanf("%d", p) != 1) {
                printf("n/a");
                flag = 1;
                break;
            }
        }
    } else {
        printf("n/a");
        flag = 1;
    }
    return flag;
}
void output(int *a, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    // NOTHING
}

void squaring(int *a, int n) {
    for (int i = 0; i < n; i++) {
        a[i] = a[i] * a[i];
    }
    // NOTHING
}
