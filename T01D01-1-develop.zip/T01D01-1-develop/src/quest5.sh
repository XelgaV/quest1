 cd door_management_fiies/
cd door_configuration/
i
vim door_1.conf
wq
