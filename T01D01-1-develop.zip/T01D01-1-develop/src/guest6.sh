 cd ai_help
bash keygen.sh
bash unifier.sh
