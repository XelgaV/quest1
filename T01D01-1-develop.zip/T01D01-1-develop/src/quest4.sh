 ps
pkill ai_door_control
